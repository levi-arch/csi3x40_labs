if (grade >= 90) {
  console.log("A+");
} else if (grade >= 85) {
  console.log("A");
} else if (grade >= 80) {
  console.log("A-");
} else if (grade >= 75) {
  console.log("B+");
} else if (grade >= 70) {
  console.log("B");
} else if (grade >= 65) {
  console.log("C+");
} else if (grade >= 60) {
  console.log("C");
} else if (grade >= 55) {
  console.log("D+");
} else if (grade >= 50) {
  console.log("D");
} else {
  console.log("E"); 
}