if (grade >= 90) {
  console.log("A+");
}