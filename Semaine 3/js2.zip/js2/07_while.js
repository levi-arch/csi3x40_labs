var i = 0;
while (i < 10) {
  i += 3;
}
console.log("The value of i is " + i);