
var c;

c = 10;
c += 3;
console.log("C is " + c);

c = 10;
c -= 3;
console.log("C is " + c);

c = 10;
c *= 3;
console.log("C is " + c);

c = 10;
c /= 5;
console.log("C is " + c);
