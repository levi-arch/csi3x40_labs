if (grade >= 90) {
  console.log("A+");
} else {
  console.log("You received " + grade); 
}