
i = 0
while (++i < 3) {}
console.log("++i loop, i is now " + i);

i = 0
while (i++ < 3) {}
console.log("i++ loop, i is now " + i);