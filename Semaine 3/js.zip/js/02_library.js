function helloWorld()
{
  document.writeln("<p>Welcome to HTML5!</p>");
}